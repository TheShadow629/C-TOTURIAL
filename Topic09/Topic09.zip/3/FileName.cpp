#include <string>
#include <fstream>
#include <sstream>
#include "Bst.h"
#include "Date.h"
#include "Vector.h"

bool operator>(const Date& lhs, const Date& rhs)
{
	if (lhs.GetYear() > rhs.GetYear())
	{
		return true;
	}
	else if (lhs.GetYear() == rhs.GetYear())
	{
		if (lhs.GetMonth() > rhs.GetMonth())
		{
			return true;
		}
		else if (lhs.GetMonth() == rhs.GetMonth())
		{
			if (lhs.GetDay() > rhs.GetDay())
			{
				return true;
			}
		}
	}
	return false;
}

bool operator<(const Date& lhs, const Date& rhs)
{
	if (lhs.GetYear() < rhs.GetYear())
	{
		return true;
	}
	else if (lhs.GetYear() == rhs.GetYear())
	{
		if (lhs.GetMonth() < rhs.GetMonth())
		{
			return true;
		}
		else if (lhs.GetMonth() == rhs.GetMonth())
		{
			if (lhs.GetDay() < rhs.GetDay())
			{
				return true;
			}
		}
	}
	return false;
}

int main()
{
	ifstream inFile("date.txt", ios::in);
	string lineStr;
	UserSpace::MyVector<Date> dates;


	while (getline(inFile, lineStr))
	{
		stringstream ss1(lineStr);
		string date;
		getline(ss1, date, ' ');

		string day, month, year;
		stringstream singleDate(date);
		getline(singleDate, day, '/');
		getline(singleDate, month, '/');
		getline(singleDate, year, '/');

		Date d;
		d.SetDay(atoi(day.c_str()));
		d.SetMonth(atoi(month.c_str()));
		d.SetYear(atoi(year.c_str()));

		dates.Add(d);
	}
	Bst<Date> dateTree(dates[0]);
	for (int i=1;i<dates.GetSize();i++)
	{
		dateTree.Insert(dateTree.GetTree(), dates[i]);
	}
	dateTree.InOrderTraversal(dateTree.GetTree());

	return 0;
}