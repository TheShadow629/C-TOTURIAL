// Version.h
// Stores information about the project as a whole.
// This is a very simple approach for very small programs where only a few classes are used.
// What would happen if there are many dozens of classes?

/*
VERSION
01	Version 1 of the Track class coded and tested
02  Version 2 of the Track class
03  Version 3 TrackTest changed.
*/
