//---------------------------------------------------
// TrackTest.cpp - unit test
// Tests the Track class
//

// The unit test for Track
// very basic at this stage
// only 2 tests

//---------------------------------------------------

#include "Track.h" // include your .h files first

#include <iostream> // then files in <>


//---------------------------------------------------

int main ()
{
	Track track; // creates a Track object called track

	cout << "1: EMPTY TRACK TEST" << endl;
	cout << track.OutputString() << endl;

	Track track2("PSY", "Gangnam Style");  // track2 object. Which constructor is used?

	cout << endl; // blank line
	cout << "2: Gangnam Style by PSY - TRACK TEST" << endl;
	cout << track2.OutputString() << endl;


	return 0;
}

//---------------------------------------------------
