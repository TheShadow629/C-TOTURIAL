//---------------------------------------------------
// Track.h - The declaration file for Track class
//
// Defines a class that stores essential information
// about a music track on a CD or ipod etc.

// See Lect03.ppt for explanations in the slides and notes for slides

#include <fstream>
#include <string>

using namespace std;

//---------------------------------------------------

#ifndef TRACK_H
#define TRACK_H

//---------------------------------------------------

class Track
{
public:
	//Track () {Clear();}  // Not preferred. See Lec03.ppt for explanations in notes

	Track ();  // preferred way in the declaration (.h file). method body is in the implementation file Track.cpp

	Track(string title, string composer); // overloaded constructor. When is this used?

	virtual ~Track () {}; // empty body as there is nothing to delete given that pointers to data are not used.
                          // why would you use virtual? See Lec-03.ppt

	void Clear ();

	string OutputString () const;

protected: // see Lec-03.ppt
	string m_title;
	string m_composer;
};

//---------------------------------------------------
#endif
//---------------------------------------------------
