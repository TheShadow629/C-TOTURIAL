//---------------------------------------------
// Track.cpp - implementation file for Track class
//---------------------------------------------

#include "Track.h"

//---------------------------------------------

Track::Track() // the constructor's body is in the implementation - see lecture 03 for why
{
	Clear();
}

Track::Track(string title, string composer) // non-default constructor
{
 	m_title = title;
	m_composer = composer;
}

void Track::Clear()
{
	m_title = "";
	m_composer = "";
}

//---------------------------------------------

string Track::OutputString() const
{
	string output;

	// If both the title and the composer are empty
	if (m_title.length() == 0 && m_composer.length() == 0)
	{
		output = "No track information";
	}
	else
	{
		output = m_title;
		output += " by ";
		// output = output + " by ";
		output += m_composer;
	}

	return output;
}

//---------------------------------------------

